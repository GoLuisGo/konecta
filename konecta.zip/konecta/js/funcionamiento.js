document.addEventListener('DOMContentLoaded', function() {

    if(document.querySelector('.hamburger')){

        
    //menu
    const hamburger = document.querySelector('.hamburger');
    const sidebar = document.querySelector('.sidebar');
    const content = document.querySelector('.content');

    hamburger.addEventListener('click', function() {
    hamburger.classList.toggle('open');
    sidebar.classList.toggle('open');
 
});
    }
// Ocultar la alerta después de 3 segundos
setTimeout(hideAlert, 3000);

});
//tabla del crud
    function actualizar(i) {
		document.getElementById("modalform").innerHTML = Actualizar_Modal[i];
      	document.getElementById("myModal").style.display = "block";
    }

    function hideAlert() {
        if(document.getElementById('alert')){
        var alert = document.getElementById('alert');
        alert.style.display = 'none';
        }
      }

	function insertar() {
		var INSERTAR = `<form method="post" class="wd100">
		<h3>INSERTAR DATOS</h3>
				<div class="form-group">

					<input required type="text" class="form-control" value="" name="nombre" id="nombre" placeholder=" ">
					<label for="nombre">Nombre</label>
					</div>

					<div class="form-group">
					<input required type="number" class="form-control" value="" name="cedula" id="cedula" placeholder=" " pattern="\d*">
					<label for="cedula">Cédula</label>
					</div>

					<div class="form-group">
					<input required type="number" class="form-control" value="" name="telefono" id="telefono" placeholder=" " pattern="\d*">
					<label for="telefono">Teléfono</label>
					</div>

					<div class="form-group">
					<input required type="date" class="form-control" value="" name="fecha" id="fecha">
					<label for="fecha">Fecha</label>
					</div>

					<div class="form-group">
					<select required class="form-control" name="genero" id="genero">
						<option value="" disabled selected>Seleccione</option>
						<option value="masculino">Masculino</option>
						<option value="femenino">Femenino</option>
					</select>
					<label for="genero"></label>
					</div>

					<div class="form-group">
					<input required type="text" class="form-control" value="" name="cliente" id="cliente" placeholder=" ">
					<label for="cliente">Cliente</label>
					</div>

					<div class="form-group">
					<select required class="form-control" name="sede" id="sede">
						<option value="" disabled selected>Seleccione</option>
						<option value="ruta_n">Ruta N</option>
						<option value="puerto_seco">Puerto Seco</option>
						<option value="buro">Buro</option>
					</select>
					<label for="sede"></label>
					</div>

					<hr><input type="submit" id="submit" class="button_g" name="insertar_dato" value="Insertar" autocomplete="off">
				</form>`;

      document.getElementById("modalform").innerHTML = INSERTAR;
      document.getElementById("myModal").style.display = "block";
    }

	function eliminar(i) {
		document.getElementById("modalform").innerHTML = Eliminar_Modal[i];
      	document.getElementById("myModal").style.display = "block";
    }

    window.onclick = function(event) {
      var modal = document.getElementById("myModal");
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
