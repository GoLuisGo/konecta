<?php
session_start();
include_once 'php/configure.php';

//getFecha("","","");
$konecta = getConnection();
$error = "";

if (isset($_REQUEST['exit'])){
    session_destroy();
    $error=' <div class="alert" id="alert">
    <strong>Correcto!</strong> Se a cerrado la sesion.
                <button type="button" onclick="hideAlert()">&times;</button>
            </div>
            ';
    session_start();
}

if(isset($_SESSION['usuario'])) { 
    header("Location: php/perfil.php");
}

if ( isset($_POST['usuario'])){
   $user = $_POST['usuario'];
   $clave = $_POST['clave'];	
    		
    $identificacion = mysqli_query($konecta,"SELECT * FROM user 
    WHERE usuario = '".$user."' AND clave = '$clave'");

    if ($identificacion){

        $estado = mysqli_query($konecta,"SELECT * FROM user
        WHERE estado = 'ACTIVO' ");

        if (!mysqli_num_rows($estado)){
            $error= '
            <div class="alert" id="alert">
            <strong>!Error! </strong> Cuenta Inactiva.
						<button type="button" onclick="hideAlert()">&times;</button>
					</div>';
        }else{
            $_SESSION['usuario'] = $user;	
            header("Location: php/perfil.php");		
        }

    }else{	
        $error= '
        <div class="alert" id="alert">
        <strong>!Error! </strong> usuario o clave incorrecto.
						<button type="button" onclick="hideAlert()">&times;</button>
					</div>';
    }		
}		
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
        <link rel="shortcut icon" href="img/icon.png" />

        <link rel="stylesheet" href="css/especificos.css">
        <link rel="stylesheet" href="css/generales.css">
        <link rel="stylesheet" href="css/personalizacion.css">
        <title>Konecta</title>
    </head>
    <body class="body">
            <?php echo $error; ?>
            <div class="form tmg5">
                <img class="bmg5 wd-max-70" src="img/logo.svg">
                <form method="post">
                    <div class="form-group">
                        <input required type="text" class="form-control" value="comunicaciones" name="usuario" id="usuario" placeholder="." autocomplete="off">
                        <label for="usuario">usuario</label>
                    </div>
                    <div class="form-group">
                        <input required type="password" class="form-control" value="Reg1234" name="clave" id="clave" placeholder="." autocomplete="off">
                        <label for="clave">clave</label>
                    </div>
                    <button>INICIAR</button>
                    <p class="message">Pagina principal <a href="https://www.konecta-group.com/es/"> Konecta </a></p>
                </form>
            </div>
    </body>
  <style>
    .alert {
      padding: 15px;
      border-radius: 4px;
      color: #155724;
      background-color: #d4edda;
      border: 1px solid #c3e6cb;
      margin-bottom: 10px;
    }

    .alert strong {
      font-weight: bold;
    }

    .alert button {
      cursor: pointer;
      background: none;
      border: none;
      color: inherit;
      font-size: 1.5rem;
      position: relative;
      top: -2px;
      float: right;
    }
  </style>


<script src="js/funcionamiento.js"></script>

           


</html>