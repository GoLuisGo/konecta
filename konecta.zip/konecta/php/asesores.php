<?php 
require('menu.php'); 

$NOMBRE_TABLA = 'adviser';
$NOMBRE_BASE = 'konecta';

//permisos
$editarn = 1;
$eliminarn = 1;
$insertarn = 1;

require('bases_BD.php'); 
?>