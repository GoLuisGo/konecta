<?php


//uso el scheme de mysql para obtener todas las columnas 
$CAMPO = mysqli_query($konecta,"select COLUMN_NAME,COLUMN_TYPE,COLUMN_COMMENT from
INFORMATION_SCHEMA.COLUMNS where TABLE_SCHEMA = '".$NOMBRE_BASE."' AND TABLE_NAME = '".$NOMBRE_TABLA."' ORDER BY ORDINAL_POSITION ASC;") or die(mysqli_error($konecta));

//$CAMPOX = mysqli_fetch_assoc($CAMPO);
if (isset($_POST['insertar_dato']) && $insertarn){

	// Valores del array
	$nombre = $_POST['nombre'];
	$cedula = $_POST['cedula'];
	$telefono = $_POST['telefono'];
	$fechaNacimiento = $_POST['fecha'];
	$genero = $_POST['genero'];
	$cliente = $_POST['cliente'];
	$sede = $_POST['sede'];

	
		// Convertir la fecha de nacimiento en un objeto DateTime
$fechaNacimientoObj = date('Y-m-d', strtotime($fechaNacimiento));
$fechaActual = date('Y-m-d');

// Verificar si la conversión fue exitosa
if (!$fechaNacimientoObj) {
    die('Fecha de nacimiento no válida');
}

// Calcular la edad
// Calcular la diferencia de fechas en segundos
$diferenciaSegundos = strtotime($fechaActual) - strtotime($fechaNacimientoObj);

// Calcular la edad en años
$edad = floor($diferenciaSegundos / (60 * 60 * 24 * 365.25));

		mysqli_query($konecta,"insert into ".$NOMBRE_TABLA." set 
		nombre = '$nombre', 
		cedula = $cedula, 
		telefono = $telefono, 
		fecha_naci = '$fechaNacimiento', 
		edad = $edad, 
		genero = '$genero', 
		cliente = '$cliente', 
		sede = '$sede',
		crea = '".$_SESSION['usuario']."'") or die(mysqli_error($konecta));
		
		$mensaje = '<div class="alert" id="alert">
		<strong>!Correcto! </strong> Al Insertar datos.
		<button type="button" onclick="hideAlert()">&times;</button>
	</div>';
}

 
if (isset($_POST['actualizar_dato'])){

	if($editarn){
		$id = $_POST['id'];

		// Valores del array
		$id = $_POST['id'];
		$nombre = $_POST['nombre'];
		$cedula = $_POST['cedula'];
		$telefono = $_POST['telefono'];
		$fechaNacimiento = $_POST['fecha'];
		$genero = $_POST['genero'];
		$cliente = $_POST['cliente'];
		$sede = $_POST['sede'];

		// Convertir la fecha de nacimiento en un objeto DateTime
$fechaNacimientoObj = date('Y-m-d', strtotime($fechaNacimiento));
$fechaActual = date('Y-m-d');

// Verificar si la conversión fue exitosa
if (!$fechaNacimientoObj) {
    die('Fecha de nacimiento no válida');
}

// Calcular la edad
// Calcular la diferencia de fechas en segundos
$diferenciaSegundos = strtotime($fechaActual) - strtotime($fechaNacimientoObj);

// Calcular la edad en años
$edad = floor($diferenciaSegundos / (60 * 60 * 24 * 365.25));



			mysqli_query($konecta,"UPDATE ".$NOMBRE_TABLA." SET 
			nombre = '$nombre', 
			cedula = $cedula, 
			telefono = $telefono, 
			fecha_naci = '$fechaNacimiento', 
			edad = $edad, 
			genero = '$genero', 
			cliente = '$cliente', 
			sede = '$sede' WHERE id = '$id'") or die(mysqli_error($konecta));
			
		
		$mensaje = '<div class="alert" id="alert">
					<strong>!Correcto! </strong> Al Actualizar datos.
					<button type="button" onclick="hideAlert()">&times;</button>
				</div>';
	}else{
		$mensaje = '<div class="alert" id="alert">
		<strong>!Error! </strong> Usted No Tiene Permisos para esta operacion.
		<button type="button" onclick="hideAlert()">&times;</button>
	</div>';
	}
}


if (isset($_POST['eliminar_dato']) && $eliminarn){

		$id = $_POST['id'];

		$ANT = mysqli_query($konecta,"SELECT * FROM ".$NOMBRE_TABLA." WHERE id = '".$id."'") or die(mysqli_error());
		$ANTX = mysqli_fetch_array($ANT);

		if($ANTX){

			mysqli_query($konecta,"DELETE FROM ".$NOMBRE_TABLA." WHERE id = ".$id."") or die(mysqli_error($konecta));
			
		
		$mensaje = '<div class="alert" id="alert">
						<strong>¡Correcto!</strong> Al Eliminar datos.
						<button type="button" onclick="hideAlert()">&times;</button>
					</div>';
		}else{
			
		$mensaje = '<div class="alert" id="alert">
						<strong>!Cuidado! </strong> Ningun dato fue Eliminar.
						<button type="button" onclick="hideAlert()">&times;</button>
					</div>';
		}
}

//consulto todos los datos
$tabla = mysqli_query($konecta,"SELECT * FROM ".$NOMBRE_TABLA) or die(mysqli_error($konecta));

while($lis = mysqli_fetch_assoc($tabla)){
	$datos[] = $lis;
}

$jsonDatos = json_encode($datos);
echo $mensaje;
?>
		<table >
			<thead id="tablaHEAD" >
			</thead>
			<tbody id="tablaBODY" >
			</tbody>
		</table>

		<div id="myModal" class="modal">
			<div class="modal-content" id="modalform">
				
			</div>
		</div>

		<script>
		//lectura y procesamiento de datos con javascrip
        var datos = <?php echo $jsonDatos; ?>;

		if(isNaN(datos)){

			const propiedades = Object.keys(datos[0]);

			let tablaHEAD = "<tr>";

			tablaHEAD += `<td>ACCIONES<br>
			<img class="wd-max-32" src="../img/add.png" id="add" onclick="insertar()"></td>`;

			for (let i = 0; i < propiedades.length; i++) {
				tablaHEAD += `<td>${propiedades[i]}</td>`;
			}
			tablaHEAD += "</tr>";

          let tablaBODY = "";

		  var Actualizar_Modal = [];
		  var Eliminar_Modal = [];
       

          for (let i = 0; i < datos.length; i++) {
              tablaBODY += "<tr>";
			  //console.log(datos[i][propiedades[4]]);
              for (let j = 0; j < propiedades.length; j++) {

				var m = "", f = "",r = "" , p ="", b="";

				if(datos[i][propiedades[6]] == "masculino"){
					m = "selected";
				}
				if(datos[i][propiedades[6]] == "Femenino"){
					f = "selected";
				}

				if(datos[i][propiedades[8]] == "ruta_n"){
					r = "selected";
				}
				if(datos[i][propiedades[8]] == "puerto_seco"){
					p = "selected";
				}
				if(datos[i][propiedades[8]] == "buro"){
					b = "selected";
				}
				var ACTUALIZAR = `<form method="post" class="wd100">
									<h3>ACTUALIZAR DATOS</h3>
									<input required type="text" class="dpn" value="${datos[i][propiedades[0]]}" name="id" id="id" placeholder=" ">
										
									<div class="form-group">
										<input required type="text" class="form-control" value="${datos[i][propiedades[1]]}" name="nombre" id="nombre" placeholder=" ">
										<label for="nombre">Nombre</label>
										</div>

										<div class="form-group">
										<input required type="number" class="form-control" value="${datos[i][propiedades[2]]}" name="cedula" id="cedula" placeholder=" " pattern="\d*">
										<label for="cedula">Cédula</label>
										</div>

										<div class="form-group">
										<input required type="number" class="form-control" value="${datos[i][propiedades[3]]}" name="telefono" id="telefono" placeholder=" " pattern="\d*">
										<label for="telefono">Teléfono</label>
										</div>

										<div class="form-group">
										<input required type="date" class="form-control" value="${datos[i][propiedades[4]]}" name="fecha" id="fecha">
										<label for="fecha">Fecha</label>
										</div>

										<div class="form-group">
										<select required class="form-control" name="genero" id="genero">
											<option value="" disabled >Seleccione</option>
											<option ${m} value="masculino">Masculino</option>
											<option ${f} value="femenino">Femenino</option>
											
										</select>
										<label for="genero"></label>
										</div>

										<div class="form-group">
										<input required type="text" class="form-control" value="${datos[i][propiedades[7]]}" name="cliente" id="cliente" placeholder=" ">
										<label for="cliente">Cliente</label>
										</div>

										<div class="form-group">
										<select required class="form-control" name="sede" id="sede">
											<option value="" disabled >Seleccione</option>
											<option ${r} value="ruta_n">Ruta N</option>
											<option ${p} value="puerto_seco">Puerto Seco</option>
											<option ${b} value="buro">Buro</option>
										</select>
										<label for="sede"></label>
										</div>

										<hr><input type="submit" id="submit" class="button" name="actualizar_dato" value="ACTUALIZAR" autocomplete="off">
									</form>`;	


									var ELIMINAR = `<form method="post" class="wd100">
														<h3>ELIMINAR DATOS</h3>
														<input required type="text" class="dpn" value="${datos[i][propiedades[0]]}" name="id" id="id" placeholder=" ">
									
														<div class="form-group">
															<input disabled type="text" class="form-control" value="${datos[i][propiedades[1]]}" name="nombre" id="nombre" placeholder=" ">
															<label for="nombre">Nombre</label>
															</div>

															<div class="form-group">
															<input disabled type="text" class="form-control" value="${datos[i][propiedades[2]]}" name="cedula" id="cedula" placeholder=" " pattern="\d*">
															<label for="cedula">Cédula</label>
															</div>

															<hr><input type="submit" class="button_r" name="eliminar_dato" value="Eliminar" autocomplete="off">
														</div>
															<hr>
															<input type="button" class="button" onclick="document.getElementById('myModal').style.display = 'none';" value="Cancelar" autocomplete="off">
													</form>`;

									Actualizar_Modal[i] = ACTUALIZAR;
									Eliminar_Modal[i] = ELIMINAR;

                if(j == 0){
                  tablaBODY += `<td><img class="wd-max-32" src="../img/up.png" id="upp" onclick="actualizar(${i})">  <img class="wd-max-32" src="../img/delete.png" id="del" onclick="eliminar(${i})"> `;
                }
                  tablaBODY += "<td>" + datos[i][propiedades[j]] + "</td>";
                
              
              }
              //tablaBODY += "<td>" + datos.resultados[i].id + "</td>";
              tablaBODY += "</tr>";
          }

          document.getElementById('tablaBODY').innerHTML = tablaBODY;
          document.getElementById('tablaHEAD').innerHTML = tablaHEAD;

		};


		
    </script>




<style>
    /* Estilos para el modal */
    .modal {
      display: none;
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
      background-color: #fff;
      margin: 0% auto;
      padding: 20px;
      border-radius: 5px;
      width: 80%;
      max-width: 400px;
    }

    /* Estilos para el formulario dentro del modal */
    .modal form {
      display: flex;
      flex-direction: column;
    }

    .modal form label {
      margin-bottom: 5px;
    }

    .modal form input[type="text"],
    .modal form textarea {
      margin-bottom: 10px;
      padding: 5px;
    }

    .modal form button {
      padding: 10px;
    }
  </style>
		
			
			</div>
		</div>
	</body>
</html>