<?php
	
	function getConnection(){
		
		$host = "localhost";
		
		$database_name = "konecta";
		
		$username = "root";

		$password = "";

		$conn;

		setlocale(LC_TIME,"es_CO");
		$conn = null;
		try{
			$conn = mysqli_connect($host, $username, $password,$database_name);
		}catch(PDOException $exception){
			echo "Imposible conectar a la base de datos: " . $exception->getMessage();
		}
		return $conn;
	}

	function getFecha($fs,$hs,$espacio){
		return $fechahoy = date ( 'Y'.$fs.'m'.$fs.'d'.$espacio.'G'.$hs.'i'.$hs.'s',strtotime('00 hour, -00 minutes, -00 seconds,',strtotime(date('Y-m-d G:i:s'))));
	}


?>