<?php 
    session_start();

    if(!isset($_SESSION['usuario'])) { 
        header("Location: ../login.php");
    } 
    error_reporting(0);

    include_once 'configure.php';
    //varibles globales
    $konecta = getConnection();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
        <link rel="shortcut icon" href="img/icon.png" />

        <link rel="stylesheet" href="../css/especificos.css">
        <link rel="stylesheet" href="../css/generales.css">
        
        <link rel="stylesheet" href="../css/personalizacion.css">

       
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        
       <title>Konecta</title>
    </head>
    <body>

   

        <div class="hamburger" id="hamburger">
            <span></span>
            <span></span>
            <span></span>
        </div>
        
        <div class="sidebar Z">
            <ul class="list tpd3" >
                <li><a href="perfil.php"><i class="fas fa-user"></i>Perfil</a></li>
                <li><a href="asesores.php"><i class="fas fa-users"></i>Asesores</a></li>
                <li><img class="wd-max-6" src="../img/cerrar.png"><a href="../login.php?exit=exit">Cerrar Sesion</a></li>
            </ul>
        </div>


        <div class="content">
        <img class="wd-max-70" src="../img/logo.svg"><br>
            <p>Bienvenido al sitio web.</p>
        </div>

        <style>

    .sidebar {
      width: 200px;
      background-color: #333;
      color: #fff;
    }

    .sidebar ul {
      list-style: none;
      padding: 0;
      margin: 0;
      margin-top: 35px;
    }

    .sidebar li {
      padding: 10px;
      cursor: pointer;
    }

    .sidebar li a {
      color: #fff;
      text-decoration: none;
      margin-left: 10px;
    }

    .sidebar li:hover {
      background-color: #555;
    }

    .content {
        text-align: center;
        width: 100%;
      padding: 20px;
    }
  </style>

    <script src="../js/funcionamiento.js"></script>

           




        
    </body>
</html>