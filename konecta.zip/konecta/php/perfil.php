<?php 
require('menu.php');

$perfil = mysqli_query($konecta,"SELECT * FROM user
WHERE usuario = '".$_SESSION['usuario']."' ");

if (mysqli_num_rows($perfil)){
	$perfilex = mysqli_fetch_assoc($perfil);
}

?>
  <style>

    .profile-card {
      background-color: #f1f1f1;
      border-radius: 8px;
      padding: 20px;
	  margin-left: 20%;
	  margin-right: 20%;
      text-align: center;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    .profile-card img {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 15px;
    }

    .profile-card h2 {
      margin: 0;
      font-size: 24px;
    }

    .profile-card p {
      margin: 10px 0;
      font-size: 16px;
    }
  </style>

  <div class="profile-card">
    <img src="../img/perfil.png" alt="Profile Picture">
    <h2><?php echo $perfilex['usuario']; ?></h2>
    <p>Descripción del perfil</p>
    <p>ESTADO: <?php echo $perfilex['estado']; ?></p>
  </div>
